
Naman Gujarathi AED Assignment 2
# Echo_Health

>This application can be used for storing, retrieving an updating the details of patients, doctor, Community Admin, System Admin and Hospital admin 

>This application just runs crud operations over the records saved in memory. It run on datastructure Arraylist. In this desktop based application there is no database is used

## Functionalities

*Create the data for patient. It has dynamic validations for every field*

*View the data of the patient by clicking the name field of the table*

*Update the details with similar validations as create functionality*

*Delete the record of the patient*

*Search the patient record. It has dynamic search functionality*
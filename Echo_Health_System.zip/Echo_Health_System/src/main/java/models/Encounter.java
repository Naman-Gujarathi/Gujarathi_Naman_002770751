package models;

import java.util.Date;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author karan
 */
public class Encounter {
    private int encounterID;
    private Date date;
    private Doctor doctor;
    private Hospital hospital;
    private VitalSigns vitalSigns;
    private Patient patient;

    
    
    public Encounter(Date date, Doctor doctor, Hospital hospital, Patient patient, int encounterID) {
        this.date = date;
        this.doctor = doctor;
        this.hospital = hospital;
        this.patient = patient;
        this.encounterID = encounterID;
        this.vitalSigns = new VitalSigns();
    }

    public int getEncounterID() {
        return encounterID;
    }

    public void setEncounterID(int encounterID) {
        this.encounterID = encounterID;
    }
    
    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public Hospital getHospital() {
        return hospital;
    }

    public void setHospital(Hospital hospital) {
        this.hospital = hospital;
    }

    public VitalSigns getVitalSigns() {
        return vitalSigns;
    }

    public void setVitalSigns(VitalSigns vitalSigns) {
        this.vitalSigns = vitalSigns;
    }
}
